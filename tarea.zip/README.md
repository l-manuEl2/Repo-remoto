# codificador
